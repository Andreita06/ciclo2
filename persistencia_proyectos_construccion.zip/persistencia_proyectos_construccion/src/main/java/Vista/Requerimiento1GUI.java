package Vista;

import java.util.ArrayList;

import Controlador.ElControladorDeRequerimientos;

import Modelo.vo.Requerimiento_1;
import Modelo.vo.Requerimiento_2;
import Modelo.vo.Requerimiento_3;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;

public class Requerimiento1GUI extends JFrame{
    //public static final ElControladorDeRequerimientos CONTROLADOR = new ElControladorDeRequerimientos();

    private JTable tbRequerimiento1;

    public void iniciarGUI(){
        setTitle("Requerimientos");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        btnRequerimiento1 = new JButton("Proyectos en Bogotá");
        btnRequerimiento1.addActionListener(CONTROLADOR);
        btnRequerimiento1.setActionCommand("requerimiento1");

        btnRequerimiento2 = new JButton("Información Líderes");
        btnRequerimiento2.addActionListener(CONTROLADOR);
        btnRequerimiento2.setActionCommand("requerimiento2");

        btnRequerimiento3 = new JButton("Compras Jumbo");
        btnRequerimiento3.addActionListener(CONTROLADOR);
        btnRequerimiento3.setActionCommand("requerimiento3");

        JPanel panel = new JPanel();
        panel.add(btnRequerimiento1);
        panel.add(btnRequerimiento2);
        panel.add(btnRequerimiento3);

        getContentPane().add(panel);

        setSize(800,200);
        setLocationRelativeTo(null);
        setVisible(true);

    }


    public static void requerimiento1(){
        
        try {
            // Su código
            ArrayList<Requerimiento_1> lista1 = CONTROLADOR.consultarRequerimiento1();

            for(Requerimiento_1 reque : lista1){
                System.out.printf("%d %s %s %s %n",
                reque.getID_Proyecto(),
                reque.getCiudad(),
                reque.getBanco_Vinculado(),
                reque.getConstructora()
                );
            }
        } catch (Exception e) {
            System.err.println("Ha ocurrido un error!"+e.getMessage());
        }
    }

    public static void requerimiento2(){
        
        try {
            // Su código
            ArrayList<Requerimiento_2> lista2 = CONTROLADOR.consultarRequerimiento2();

            for(Requerimiento_2 reque : lista2){
                System.out.printf("%s %s %s %s %s %n", 
                reque.getNombre(),
                reque.getPrimer_Apellido(),
                reque.getCiudad_Residencia(),
                reque.getCargo(),
                reque.getSalario()
                );
            }
        } catch (Exception e) {
            System.err.println("Ha ocurrido un error!"+e.getMessage());
        }
    }

    public static void requerimiento3(){
        try {
           // Su código
           ArrayList<Requerimiento_3> lista3 = CONTROLADOR.consultarRequerimiento3();

            for(Requerimiento_3 reque : lista3){
                System.out.printf("%s %s %s %n", 
                reque.getProveedor(),
                reque.getPagado(),
                reque.getConstructora()                
                );
            }
        } catch (Exception e) {
            System.err.println("Ha ocurrido un error!"+e.getMessage());
        }
    }
}
