package Controlador;

import java.sql.SQLException;
import java.util.ArrayList;

import Modelo.dao.Requerimiento_1Dao;
import Modelo.dao.Requerimiento_2Dao;
import Modelo.dao.Requerimiento_3Dao;

import Modelo.vo.Requerimiento_1;
import Modelo.vo.Requerimiento_2;
import Modelo.vo.Requerimiento_3;

import Vista.VistaRequerimientos;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class ElControladorDeRequerimientos implements ActionListener{
    
    private final Requerimiento_1Dao REQUERIMIENTO_1DAO;
    private final Requerimiento_2Dao REQUERIMIENTO_2DAO;
    private final Requerimiento_3Dao REQUERIMIENTO_3DAO;
    private VistaRequerimientos vistaRequerimientos;

    public ElControladorDeRequerimientos(){
        this.REQUERIMIENTO_1DAO= new Requerimiento_1Dao();
        this.REQUERIMIENTO_2DAO= new Requerimiento_2Dao();
        this.REQUERIMIENTO_3DAO= new Requerimiento_3Dao();
        this.vistaRequerimientos= new VistaRequerimientos();
    }
    
        public ArrayList<Requerimiento_1> consultarRequerimiento1() throws SQLException {
            // Su código
            return this.REQUERIMIENTO_1DAO.requerimiento1();
        }
    
        public ArrayList<Requerimiento_2> consultarRequerimiento2() throws SQLException {
            // Su código
            return this.REQUERIMIENTO_2DAO.requerimiento2();
        }
    
        public ArrayList<Requerimiento_3> consultarRequerimiento3() throws SQLException {
            // Su código
            return this.REQUERIMIENTO_3DAO.requerimiento3();
        } 

        public void inicio(){
            this.vistaRequerimientos.iniciarGUI();
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            String actionCommand = ((JButton)e.getSource()).getActionCommand();
            
            switch(actionCommand){
                case "requerimiento1":
                    System.out.println("Consulta1");
                    try {
                        ArrayList<Requerimiento_1> resultado = consultarRequerimiento1();
                        Object matriz [][] = new Object[resultado.size()][4];
                        for(int i = 0; i < resultado.size();i++){
                            //SELECT ID_Proyecto, Ciudad, Banco_Vinculado, Constructora 
                            matriz[i][0]=resultado.get(i).getID_Proyecto();
                            matriz[i][1]=resultado.get(i).getCiudad();
                            matriz[i][2]=resultado.get(i).getBanco_Vinculado();
                            matriz[i][3]=resultado.get(i).getConstructora();
                        }
                        Modelo modelo = new Modelo();
                        modelo.datos = matriz;
                        JTable tabla = new JTable(modelo);
                        JScrollPane scroll = new JScrollPane(tabla);
                        JOptionPane.showMessageDialog(null, scroll);
                    } catch (SQLException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                break;

                case "requerimiento2":
                System.out.println("Consulta 2");
                    try {
                        ArrayList<Requerimiento_2> resultado = consultarRequerimiento2();
                        Object matriz [][] = new Object[resultado.size()][5];
                        for(int i = 0; i < resultado.size();i++){
                            //SELECT Nombre, Primer_Apellido, Ciudad_Residencia, Cargo, Salario 
                            matriz[i][0]=resultado.get(i).getNombre();
                            matriz[i][1]=resultado.get(i).getPrimer_Apellido();
                            matriz[i][2]=resultado.get(i).getCiudad_Residencia();
                            matriz[i][3]=resultado.get(i).getCargo();
                            matriz[i][4]=resultado.get(i).getSalario();
                        }
                        Modelo modelo = new Modelo();
                        modelo.datos = matriz;
                        JTable tabla = new JTable(modelo);
                        JScrollPane scroll = new JScrollPane(tabla);
                        JOptionPane.showMessageDialog(null, scroll);
                    } catch (SQLException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                break;

                case "requerimiento3":
                System.out.println("Consulta 3");
                try {
                    ArrayList<Requerimiento_3> resultado = consultarRequerimiento3();
                    Object matriz [][] = new Object[resultado.size()][3];
                    for(int i = 0; i < resultado.size();i++){
                         
                        matriz[i][0]=resultado.get(i).getProveedor();
                        matriz[i][1]=resultado.get(i).getPagado();
                        matriz[i][2]=resultado.get(i).getConstructora();
                    }
                    Modelo modelo = new Modelo();
                    modelo.datos = matriz;
                    JTable tabla = new JTable(modelo);
                    JScrollPane scroll = new JScrollPane(tabla);
                    JOptionPane.showMessageDialog(null, scroll);
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                break;
            }
        }
}